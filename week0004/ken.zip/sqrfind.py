import math

class SqrFind():
	def __init__(self):
		# init stuff
		self.cache = {}
		self.sqrt = {}
		self.revsqr = {}
		#self.maxrange = 2147483647
		#self.halfrange = math.floor(math.sqrt(self.maxrange))
		#self.twos = []
		#print('init half:'+str(self.halfrange))
		#self.createLookup()
		#self.spitResult(self.maxrange)
		#self.spitResult(2)

	def spitResult(self, base):
		basehalf = base /2.0
		if(base in self.sqrt):
			start = self.sqrt[base]
		else:
			v = math.sqrt(base)
			self.sqrt[base] = v
			start = math.floor(v)
		check = 0
		matches = 0
		
		if(start in self.cache):
			#print('found cache mult')
			n = self.cache[start]
		else:
			n = start*start
			self.cache[start] = n
			self.revsqr[n] = start
		#print('start: '+str(n))
		while n >= basehalf:
			check = base - n
			#char = str(check)
			#last = char[len(char)-3]
			last = check % 10
			#if((last == '1') | (last == '4') | (last == '5') | (last == '6') | (last == '9') | (last == '0')):
			if((last == 1) | (last == 4) | (last == 5) | (last == 6) | (last == 9) | (last == 0)):
				#print('check: '+str(check))
				match = False
				if(check in self.revsqr):
					#print('rev sqr match found')
					match = True
				else:
					if(check in self.sqrt):
						#print('found cache sqrt')
						root = self.sqrt[check]
					else:
						root = math.sqrt(check)
						self.sqrt[check] = root
						
					if(root%1 == 0):
						#print(str(start)+'^2 + '+str(root)+'^2')
						self.cache[root] = check
						self.revsqr[check] = root
						match = True
				if(match):
					matches = matches + 1
			start = start-1
			if(start in self.cache):
				#print('found cache mult')
				n = self.cache[start]
			else:
				n = start*start
				self.cache[start] = n
				self.revsqr[n] = start
			#print('new n: '+str(n))
			if(n > base): 
				#print(str(n)+' over '+str(base)+' breaking out')
				break
		print(str(matches))