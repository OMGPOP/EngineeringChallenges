from sqrfind import SqrFind
import sys


tester = SqrFind()
if(len(sys.argv) > 1):
	f = open(sys.argv[1])
	
	ct = 0;
	for line in f:
		if(ct > 0):
			tester.spitResult(long(line))
		ct = ct + 1
else:
	f = open('input.txt')
	ct = 0;
	
	#tester.spitResult(25)
	for line in f:
		if(ct > 0):
			tester.spitResult(long(line))
		ct = ct + 1