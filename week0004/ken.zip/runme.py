from sqrfind import SqrFind
import sys


tester = SqrFind()
if(len(sys.argv) > 1):
	f = open(sys.argv[1])
	
	ct = 0;
	for line in f:
		if(ct > 0):
			tester.spitResult(long(line))
		ct = ct + 1
else:
	print('Please pass in the path to the input file.')
	print('eg: python sqrtester.py /home/ken/input.txt')
	print('Using default - input.txt')
	print('===========================================')
	f = open('input.txt')
	ct = 0;
	
	#tester.spitResult(100)
	for line in f:
		if(ct > 0):
			tester.spitResult(long(line))
		ct = ct + 1