#from sqrfind import SqrFind
from precalc import SqrFind
import sys
from time import time


tester = SqrFind()
#tester.spitResult(2147483647)
results = []

'''
for j in range(10):
	startTime = time()
	resultprint =''
	for i in range(50000):
		new = str(tester.spitResult(i)) + '\n'
		resultprint = resultprint + new
	print(resultprint)
	elapsed = time() - startTime
	results.append(elapsed)

add = 0
for i in results:
	add += i
avg = add / len(results)
print('completed: '+str(avg))
'''
resultprint = ''
if(len(sys.argv) > 1):
	f = open(sys.argv[1])
	
	ct = 0;
	for line in f:
		if(ct > 0):
			new = str(tester.spitResult(long(line))) + '\n'
			resultprint = resultprint + new
		ct = ct + 1
else:
	f = open('input.txt')
	ct = 0;
	
	#tester.spitResult(25)
	for line in f:
		if(ct > 0):
			new = str(tester.spitResult(long(line))) + '\n'
			resultprint = resultprint + new
		ct = ct + 1
print(resultprint)
