import math

class SqrFind():
	def __init__(self):
		self.maxrange = 2147483647
		self.halfrange = int(math.floor(math.sqrt(self.maxrange)))
		self.keeptrack = 0
		self.squares = {0:0}
		self.roots = {0:0}
		self.buildLookup()
	
	def buildLookup(self):
		i=1
		while i <= self.halfrange:
			self.keeptrack += 2*i - 1
			self.squares[i] = self.keeptrack
			self.roots[self.keeptrack] = i
			i = i + 1
	
	def spitResult(self, base):
		basehalf = base /2.0
		start = math.floor(math.sqrt(base))
		end = math.floor(math.sqrt(basehalf))
		matches = 0
		while start > end:
			first = self.squares[start]
			left = base - first
			if(left in self.roots):
				matches = matches +1
			start = start - 1
		print(str(matches))